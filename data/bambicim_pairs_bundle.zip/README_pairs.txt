Bambicim pairs bundle

Files:
- pairs_bambicim_xl.jsonl  (~377 pairs)
- pairs_bambicim_big.jsonl (~168 pairs)
- pairs_bambicim_final.jsonl (~62 pairs)

Usage:
1) Pick one and copy it into your project as data/pairs.jsonl
2) Run: python scripts/train_copilot_dense.py
